package com.codingdojo.daikichi;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
@Controller
public class NonrestController {
    @PostMapping("/Omikuji/show")
    public String show() {
   	 return "index.jsp";
    }
    @PostMapping("/omikuji/processing")
    public String sendMessage(HttpSession session, Model model) {
    	@RequestParam(value="number")String number,
    	@Requestparam
    	
    	session.setAttribute(number ,"number");
    	String city = (String)session.setAttribute("city");
    	String name = (String)session.setAttribute("name");
    	String hobby =(String)session.setAttribute("hobby");
    	String thing =(String)session.setAttribute("thing");
    	String compliment =(String)session.setAttribute("compliment");
    	return "redirect:/Omikuji/show";
    }
    @RequestMapping("/Omikuji")
    public String form(HttpSession session Model model) {
    	Integer number = (Integer)session.getAttribute("number");
    	String city = (String)session.getAttribute("city");
    	String name = (String)session.getAttribute("name");
    	String hobby =(String)session.getAttribute("hobby");
    	String thing =(String)session.getAttribute("thing");
    	String compliment =(String)session.getAttribute("compliment");
   	 return "omikuji.jsp";
    }
   
}
