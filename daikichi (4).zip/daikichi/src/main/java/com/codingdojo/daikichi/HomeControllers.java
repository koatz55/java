package com.codingdojo.daikichi;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/daikichi")
public class HomeControllers {
     @RequestMapping("")
     public String Welcome() {
             return "Welcome!";
     }
     @RequestMapping("/luck")
     public String luck() {
             return "luck is on its way";
     }
     @RequestMapping("/blessing") 
     public String bless() {
    	 return "you will be blessed today";
     }
     @RequestMapping("/travel/")
     public String travel(@RequestParam(value="q") String searchQuery) {
         return "You will travel and have a good time in " + searchQuery + ".";
     }
     @RequestMapping("/lotto/")
     public String lotto(@RequestParam(value="q") Integer searchQuery) {
    	 if( searchQuery % 2 == 0) {
    		 return "You will a graet time with your family";
    	 }
         return "You will travel but beware of strang offers... ";
     }
}
     