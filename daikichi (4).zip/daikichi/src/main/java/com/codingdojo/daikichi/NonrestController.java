package com.codingdojo.daikichi;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
@Controller
public class NonrestController {
    @GetMapping("/Omikuji/show")
    public String show(HttpSession session, Model model) {
      	String number = (String)session.getAttribute("number");
    	String city = (String)session.getAttribute("city");
    	String name = (String)session.getAttribute("name");
    	String hobby =(String)session.getAttribute("hobby");
    	String thing =(String)session.getAttribute("thing");
    	String compliment =(String)session.getAttribute("compliment");
    	
    	model.addAttribute("compliment",compliment);
    	model.addAttribute("thing",thing);
    	model.addAttribute("hobby",hobby);
    	model.addAttribute("name",name);
    	model.addAttribute("city", city);
    	model.addAttribute("number",number);
    	return "index.jsp";
    	}
    
    @PostMapping("/omikuji/processing")
    public String sendMessage(HttpSession session,
    	@RequestParam(value="number")String number,
    	@RequestParam(value="city")String city,
    	@RequestParam(value="name")String name,
    	@RequestParam(value="hobby")String hobby,
    	@RequestParam(value="thing")String thing,
    	@RequestParam(value="compliment")String compliment) {
    	
    	session.setAttribute("number",number );
    	session.setAttribute("city", city);
    	session.setAttribute("name",name);
    	session.setAttribute("hobby", hobby);
    	session.setAttribute("thing", thing);
    	session.setAttribute("compliment", compliment);
    	return "redirect:/Omikuji/show";
    	}
    
    @GetMapping("/omikuji")
    public String form() {
    	return "omikuji.jsp";
    }
   
}
