package com.codingdojo.authentication.controllers;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.codingdojo.authentication.models.Language;
import com.codingdojo.authentication.models.LoginUser;
import com.codingdojo.authentication.models.User;
import com.codingdojo.authentication.services.UserService;

//.. don't forget to inlcude all your imports! ..

@Controller
public class HomeController {
 
 // Add once service is implemented:
 // @Autowired
 // private UserService userServ;
	@Autowired
	private UserService userServ;
 @GetMapping("/")
 public String index(Model model) {
	 ArrayList<Language> allLaguages = new ArrayList<Language>();
	 allLaguages.add(new Language("python"));
	 allLaguages.add(new Language("Java"));
	 allLaguages.add(new Language("Mern"));
     // Bind empty User and LoginUser objects to the JSP
     // to capture the form input
     model.addAttribute("newUser", new User());
     model.addAttribute("newLogin", new LoginUser());
     model.addAttribute("allLaguages", allLaguages);

     return "index.jsp";
 }
 
 @PostMapping("/register")
 public String register(@Valid @ModelAttribute("newUser") User newUser, 
         BindingResult result, Model model, HttpSession session) {
     
     // TO-DO Later -- call a register method in the service 
	 userServ.register(newUser, result);
     // to do some extra validations and create a new user!
     
     if(result.hasErrors()) {
         // Be sure to send in the empty LoginUser before 
         // re-rendering the page.
    	 ArrayList<Language> allLaguages = new ArrayList<Language>();
    	 allLaguages.add(new Language("python"));
    	 allLaguages.add(new Language("Java"));
    	 allLaguages.add(new Language("Mern"));
         model.addAttribute("allLaguages", allLaguages);
    	 model.addAttribute("newLogin", new LoginUser());
         return "index.jsp";
     }
     
     // No errors! 
     // TO-DO Later: Store their ID from the DB in session, 
     session.setAttribute("userId", newUser.getId() );
     // in other words, log them in.
 
     return "redirect:/welcome";
 }
 
 @PostMapping("/login")
 public String login(@Valid @ModelAttribute("newLogin") LoginUser newLogin, 
         BindingResult result, Model model, HttpSession session) {
     
     // Add once service is implemented:
     User user = userServ.login(newLogin, result);


     if(user == null) { 
    	 ArrayList<Language> allLaguages = new ArrayList<Language>();
    	 allLaguages.add(new Language("python"));
    	 allLaguages.add(new Language("Java"));
    	 allLaguages.add(new Language("Mern"));
    	 model.addAttribute("newUser", new User());
//    	 model.addAttribute("newLogin", new LoginUser());
         model.addAttribute("allLaguages", allLaguages);

     	return "index.jsp";
     }
     
     // No errors! 
     // TO-DO Later: Store their ID from the DB in session,
     session.setAttribute("userId", user.getId() );

     // in other words, log them in.
 
     return "redirect:/welcome";
 }
 
 @GetMapping("/logout")
 public String logout(HttpSession session) {
	 session.setAttribute("userId", null);
	 return "redirect:/";
 }
 
 @GetMapping("/welcome")
 public String welcome(HttpSession session, Model model) {
	 //Don't forget to cast
	 Long userId =  (Long) session.getAttribute("userId");
	 if(userId == null) {
		 return "redirect:/";
	 }
	 User user = userServ.findById(userId);
	 model.addAttribute("user", user);
	 return "dashboard.jsp";
 }
 
 
 
 
 
 
 
 
 
 
}
