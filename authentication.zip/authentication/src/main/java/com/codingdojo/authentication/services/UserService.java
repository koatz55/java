package com.codingdojo.authentication.services;

import java.util.Optional;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindingResult;
    
import com.codingdojo.authentication.models.LoginUser;
import com.codingdojo.authentication.models.User;
import com.codingdojo.authentication.repositories.UserRepository;
    
@Service
public class UserService {
    
    @Autowired
    private UserRepository userRepo;
    
    // TO-DO: Write register and login methods!
    // This method will be called from the controller
    // whenever a user submits a registration form.
    
    	public User register(User newUser, BindingResult result) {
    
    	// TO-DO - Reject values or register if no errors:
        
        // Reject if email is taken (present in database)
    		Optional<User> potentialUser = userRepo.findByEmail(newUser.getEmail());
    		if(potentialUser.isPresent() ) {
    			result.rejectValue("email", "Matches", "Email is Taken");
    		}

        // Reject if password doesn't match confirmation
    		if(!newUser.getPassword().equals(newUser.getConfirm())) {
    		    result.rejectValue("confirm", "Matches", "The Confirm Password must match Password!");
    		}

        // Return null if result has errors
    		if(result.hasErrors()) {
		    // Exit the method and go back to the controller 
		    // to handle the response
		    return null;
    		}
        // Hash and set password, save user to database
    		String hashed = BCrypt.hashpw(newUser.getPassword(), BCrypt.gensalt()); 
    		newUser.setPassword(hashed);
    		return userRepo.save(newUser);
    }

    // This method will be called from the controller
    // whenever a user submits a login form.
        public User login(LoginUser newLoginObject, BindingResult result) {
        // TO-DO - Reject values:
        
        	// Return null if result has errors
        	if(result.hasErrors()) {
        		System.out.println(result.hasErrors());
        		return null;
        	}
    	// Find user in the DB by email
        	Optional<User> potentialUser = userRepo.findByEmail(newLoginObject.getEmail());
        // Reject if NOT present
        	if(!potentialUser.isPresent()) {
        		result.rejectValue("email", "Matches", "Invalid Password or Email");
        		return null;
        	}
        	String passwordEntered = newLoginObject.getPassword();
        // Reject if BCrypt password match fails
        	if(!BCrypt.checkpw(passwordEntered,potentialUser.get().getPassword())) {
        		result.rejectValue("password", "Matches", "Invalid Password or Email");
        	}
        // Otherwise, return the user object
        	return potentialUser.get();
    }

        public User findById(Long id) {
        	Optional<User> user = userRepo.findById(id);
        	if(user.isPresent()) {
        		return user.get();
        	}
        	return null;
        }
}
