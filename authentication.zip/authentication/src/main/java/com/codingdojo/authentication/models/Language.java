package com.codingdojo.authentication.models;

public class Language {
	private String name;
	
	public Language(String name) {
		this.setName(name);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
